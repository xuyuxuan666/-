#include <iostream>
#include <vector>
using namespace std;

vector<int> split_nums(int num){
    vector<int> res;
    while(num!=0){
        res.push_back(num%10);
        num /= 10;
    }
    res = vector<int>(res.rbegin(), res.rend());
    return res;
}
int solve(vector<int> &arr, int i, int j){

    
    if(j>=arr.size()){
        return 0;
    }
    if(i==j){
        if(arr[i]>0 ){
            return 1;
        }else{
            return 0;
        }
    }else if (j-i>1){
        if(j-i==1){
            if(arr[i]!=0 && arr[j]!=0){
                int num = arr[i]*10 + arr[j];
                if (num <=26&& num >0){
                    return 1+solve(arr, i, i)*solve(arr, j, j);
                }else{
                    return 0;
                }
            }
        }
        if(j-i>1){
            return solve(arr, i, i)*solve(arr, i+1, j)+solve(arr,i,i+1)*solve(arr,i+2, j);
        }
        
    }else if(i>j){
        return 1;
    }
    

}
int test(int k){
    vector<int> arr = split_nums(k);
    return solve(arr, 0, arr.size()-1);
}
int main(){
    cout<<test(12)<<endl;
    cout<<test(226)<<endl;
    cout<<test(0)<<endl;
    system("pause");
}