#include <iostream>
#include <vector>
using namespace std;

int times(vector<int> arr){
    int counts=0;
    int num=0;
    for(int i=0; i<arr.size(); ++i){
        if (arr[i] == num && counts>0){
            counts++;
        }else{
            if(counts==0){
                num = arr[i];
                counts++;
            }else{
                counts--;
            }
            
        }
    }
    return num;
}
int main(){
    vector<int> arr={1,7,2,7,-5,7,7};
    cout<<times(arr);
    system("pause");
}