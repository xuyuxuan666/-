#include <iostream>
#include <limits>
#include <vector>
using namespace std;

int max_sum(vector<int> arr){
    int max = INT32_MIN;
   for(int i=0; i<arr.size(); ++i){
     
     for(int j=i; j< arr.size(); ++j){
        int sum =0;
        for(int k=i; k<=j; ++k){
            sum +=arr[k];
            if(sum>max){
                max = sum;
            }

        }
     }
   }
   return max;
}

int main(){
    vector<int> arr1 = {1, -4, 1, 5, -10, 23};
    vector<int> arr2 = {2, -10, 4, 9, -29,10};
    cout<<max_sum(arr1)<<endl;
    cout<<max_sum(arr2)<<endl;
    system("pause");
}