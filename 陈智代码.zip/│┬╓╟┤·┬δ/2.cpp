#include <iostream>
#include <string>
#include <stack>
using namespace std;


bool right(string str){
    stack<char> st;
    for(auto i: str){
        if (!st.empty()){
            if(st.top()=='{'&&i=='}'){
                st.pop();
            }else if(st.top()=='(' && i==')'){
                st.pop();
            }else if(st.top()=='[' && i==']'){
                st.pop();
            }else{
                st.push(i);
            }
        }else{
            st.push(i);
        }
    }
    return st.empty();
    
}

int main(){
    string a="{[()()]}";
    string b="{([)]}";
    cout<<right(a)<<endl;
    cout<<right(b)<<endl;
    system("pause");
}